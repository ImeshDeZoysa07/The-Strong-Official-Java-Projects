
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

 class ClassicCardGame {

    static final int MAX_POINTS = 30;
    static final int NUM_BONUS_POINTS = 5;
    static final int NUM_TRAP_POINTS = 5;
    static final int NUM_DICE_SIDES = 6;
    static final int DICE_SIDE_MIN_POINTS = 1;
    static final int DICE_SIDE_MAX_POINTS = 4;
    static ArrayList<Integer> bonusPoints = new ArrayList<>();
    static ArrayList<Integer> trapPoints = new ArrayList<>();

    static class Player {

        int score;
        int bonusCount;
        boolean skippedTurn;

        Player() {
            this.score = 0;
            this.bonusCount = 0;
            this.skippedTurn = false;
        }

        boolean hasWon() {
            return score >= MAX_POINTS;
        }

        void addBonus() {
            this.score += 2;
            this.bonusCount++;
        }

        void reduceScore() {
            this.score -= 2;
        }

        void skipTurn() {
            this.skippedTurn = true;
        }
    }

    static class Bonus {

        int type;

        Bonus(int type) {
            this.type = type;
        }

        void activate(ArrayList<Player> players, Player currentPlayer) {
            switch (this.type) {
                case 1:
                    currentPlayer.addBonus();
                    break;
                case 2:
                    for (Player player : players) {
                        if (player != currentPlayer) {
                            player.reduceScore();
                        }
                    }
                    break;
                case 3:
                    currentPlayer.bonusCount++;
                    break;
                default:
                    break;
            }
        }
    }

    static class Trap {

        int type;

        Trap(int type) {
            this.type = type;
        }

        void activate(ArrayList<Player> players, Player currentPlayer) {
            switch (this.type) {
                case 1:
                    currentPlayer.reduceScore();
                    break;
                case 2:
                    for (Player player : players) {
                        if (player != currentPlayer) {
                            player.addBonus();
                        }
                    }
                    break;
                case 3:
                    currentPlayer.skipTurn();
                    break;
                default:
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        // Initialize players
        System.out.print("Enter number of players (2-4): ");
        int numPlayers = scanner.nextInt();
        ArrayList<Player> players = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) {
            players.add(new Player());
        }

        // Initialize bonus and trap points
        for (int i = 0; i < NUM_BONUS_POINTS; i++) {
            int point = random.nextInt(MAX_POINTS - 1) + 1;
            while (bonusPoints.contains(point)) {
                point = random.nextInt(MAX_POINTS - 1) + 1;
            }
            bonusPoints.add(point);
        }
        for (int i = 0; i < NUM_TRAP_POINTS; i++) {
            int point = random.nextInt(MAX_POINTS - 1) + 1;
            while (trapPoints.contains(point) || bonusPoints.contains(point)) {
                point = random.nextInt(MAX_POINTS - 1) + 1;
            }
            trapPoints.add(point);
        }

    // Game loop
        int currentPlayerIndex = 0;
        boolean gameOver = false;
        while (!gameOver) {
            Player currentPlayer = players.get(currentPlayerIndex);
            if (currentPlayer.skippedTurn) {
                currentPlayer.skippedTurn = false;
            } else {
                System.out.println("Player " + (currentPlayerIndex + 1) + " turn. Current score: " + currentPlayer.score);
                System.out.println("Press enter to roll the dice.");
                scanner.nextLine();
                int diceRoll = random.nextInt(NUM_DICE_SIDES) + 1;
                int diceValue = random.nextInt(DICE_SIDE_MAX_POINTS - DICE_SIDE_MIN_POINTS + 1) + DICE_SIDE_MIN_POINTS;
                currentPlayer.score += diceValue;
                System.out.println("You rolled a " + diceValue + ".");
                System.out.println("Your score is now " + currentPlayer.score + ".");
                if (bonusPoints.contains(currentPlayer.score)) {
                    System.out.println("You landed on a bonus point!");
                    Bonus bonus = new Bonus(random.nextInt(3) + 1);
                    bonus.activate(players, currentPlayer);
                    System.out.println("Your score is now " + currentPlayer.score + ".");
                }
                if (trapPoints.contains(currentPlayer.score)) {
                    System.out.println("You landed on a trap point!");
                    Trap trap = new Trap(random.nextInt(3) + 1);
                    trap.activate(players, currentPlayer);
                    System.out.println("Your score is now " + currentPlayer.score + ".");
                }
                if (currentPlayer.hasWon()) {
                    System.out.println("Player " + (currentPlayerIndex + 1) + " wins!");
                    gameOver = true;
                }
            }
            currentPlayerIndex = (currentPlayerIndex + 1) % numPlayers;
        }
    }
}


