# Software Quality Assurance - UEstates Real Estate System
This is the project which has been done for Software Quality Assurance course. UEstates is a real estate system which helps Agents to add Customers and Properties. And helps Users to search properties. The software testing types and principles have been applied to this project.

As this is the project which fulfills all the *Software Quality Assurance* standards, therefore, different sets of documents have been created such as Method & Quality Planning Document, Testing Strategy & Acceptance Test Specification Documents, Control Document and User Manual.

A complete description of this project and the documents designed can been seen in **Term Project Details Handout II.pdf** document.
