package lk.ijse.SpiceWholesaleShop.entity;

public interface SuperEntity {
}
