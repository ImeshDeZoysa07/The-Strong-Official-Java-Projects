package lk.ijse.SpiceWholesaleShop.Dao.custom.impl;

public class AttendanceDAOImpl {
}
