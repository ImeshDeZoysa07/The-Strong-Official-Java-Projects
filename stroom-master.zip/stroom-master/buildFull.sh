#!/bin/bash

./gradlew clean build "$@"

