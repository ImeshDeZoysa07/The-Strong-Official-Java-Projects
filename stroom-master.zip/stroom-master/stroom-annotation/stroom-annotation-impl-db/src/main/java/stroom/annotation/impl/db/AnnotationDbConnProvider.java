package stroom.annotation.impl.db;

import javax.sql.DataSource;

public interface AnnotationDbConnProvider extends DataSource {

}
