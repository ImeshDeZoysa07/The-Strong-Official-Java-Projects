# stroom-annotation
