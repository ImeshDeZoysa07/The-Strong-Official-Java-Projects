package stroom.activity.impl.db;

import javax.sql.DataSource;

interface ActivityDbConnProvider extends DataSource {

}
