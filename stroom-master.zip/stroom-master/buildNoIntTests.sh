#!/bin/bash
./gradlew clean build -x test "$@"

