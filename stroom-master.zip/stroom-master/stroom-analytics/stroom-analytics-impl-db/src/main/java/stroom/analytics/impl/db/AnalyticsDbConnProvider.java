package stroom.analytics.impl.db;

import javax.sql.DataSource;

public interface AnalyticsDbConnProvider extends DataSource {

}
