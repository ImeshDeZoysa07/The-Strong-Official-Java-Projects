package stroom.job.impl;

import stroom.cluster.impl.MockClusterNodeManager;
import stroom.cluster.task.impl.TargetNodeSetFactoryImpl;
import stroom.job.api.DistributedTask;
import stroom.job.api.DistributedTaskFactory;
import stroom.job.shared.Job;
import stroom.job.shared.JobNode;
import stroom.job.shared.JobNode.JobType;
import stroom.node.api.NodeInfo;
import stroom.node.mock.MockNodeInfo;
import stroom.security.mock.MockSecurityContext;
import stroom.task.api.ExecutorProvider;
import stroom.task.api.SimpleTaskContextFactory;
import stroom.task.api.TaskContextFactory;
import stroom.task.api.ThreadPoolImpl;
import stroom.task.shared.ThreadPool;
import stroom.test.common.util.test.StroomUnitTest;
import stroom.util.concurrent.ThreadUtil;
import stroom.util.logging.LambdaLogger;
import stroom.util.logging.LambdaLoggerFactory;
import stroom.util.logging.Metrics;
import stroom.util.scheduler.FrequencyScheduler;
import stroom.util.scheduler.Scheduler;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

class TestDistributedTaskFetcher extends StroomUnitTest {

    private static final LambdaLogger LOGGER = LambdaLoggerFactory.getLogger(TestDistributedTaskFetcher.class);

    @Disabled
    @Test
    void test() {
        try (final ExecutorService executors = Executors.newCachedThreadPool()) {
            final ExecutorProvider executorProvider = new ExecutorProvider() {
                @Override
                public Executor get(final ThreadPool threadPool) {
                    return executors;
                }

                @Override
                public Executor get() {
                    return executors;
                }
            };
            final TaskContextFactory taskContextFactory = new SimpleTaskContextFactory();

            final ThreadPool threadPool = new ThreadPoolImpl("MY_THREAD_POOL");
            final String jobName = "MY_DISTRIBUTED_JOB";
            final String nodeName = "NODE_NAME";
            final String frequency = "10s";
            final Job job = new Job(1, true, jobName, false);
            final JobNode jobNode =
                    new JobNode(1, nodeName, job, 100, JobType.DISTRIBUTED, frequency, true);
            final JobNodeTracker jobNodeTracker = new JobNodeTracker(jobNode);
            final Scheduler scheduler = new FrequencyScheduler(frequency);
            final JobNodeTrackerCache jobNodeTrackerCache = () -> new JobNodeTrackers() {
                @Override
                public JobNodeTracker getTrackerForJobName(final String jobName1) {
                    return jobNodeTracker;
                }

                @Override
                public List<JobNodeTracker> getDistributedJobNodeTrackers() {
                    return List.of(jobNodeTracker);
                }

                @Override
                public Scheduler getScheduler(final JobNode jobNode1) {
                    return scheduler;
                }
            };

            final NodeInfo nodeInfo = new MockNodeInfo();
            final AtomicLong executionCount = new AtomicLong();

            Metrics.setEnabled(true);

            final DistributedTaskFactory distributedTaskFactory = new DistributedTaskFactory() {
                @Override
                public List<DistributedTask> fetch(final String nodeName, final int count) {
                    if (count == 0) {
                        LOGGER.info("ZERO");
                    }

                    final List<DistributedTask> list = new ArrayList<>(count);
                    Metrics.measure("fetch", () -> {
                        for (int i = 0; i < count; i++) {
                            final Runnable runnable = () ->
                                    Metrics.measure("exec task", executionCount::incrementAndGet);
                            final DistributedTask distributedTask =
                                    new DistributedTask(jobName, runnable, threadPool, "test");
                            list.add(distributedTask);
                        }
                    });
                    return list;
                }

                @Override
                public Boolean abandon(final String nodeName, final List<DistributedTask> tasks) {
                    return Boolean.TRUE;
                }
            };
            final DistributedTaskFactoryRegistry distributedTaskFactoryRegistry = () ->
                    Map.of(jobName, distributedTaskFactory);

            final DistributedTaskFetcher distributedTaskFetcher =
                    new DistributedTaskFetcher(
                            executorProvider,
                            taskContextFactory,
                            jobNodeTrackerCache,
                            nodeInfo,
                            new MockSecurityContext(),
                            distributedTaskFactoryRegistry,
                            new TargetNodeSetFactoryImpl(nodeInfo, new MockClusterNodeManager(nodeInfo)));
            distributedTaskFetcher.execute();

            while (true) {
                Metrics.report();
                ThreadUtil.sleep(1000);
            }
        }
    }
}
