import java.util.ArrayList;
import java.util.List;

import entity.CustomerEntity;
import entity.embeded.CustomerName;
import entity.repository.CustomerRepository;
import util.SessionFactoryConfiguration;

public class App {
    public static void main(String[] args)  throws Exception {
        CustomerRepository customerRepository = new CustomerRepository();

        // StudentName studentName = new StudentName("Student 1 First", "Student 1 Last");

        // List<String> mobiles = new ArrayList<>();
        //mobiles.add("0778988876");
        // mobiles.add("0778983876");

        // StudentEntity entity = new StudentEntity();
        // entity.setMobiles(mobiles);
        // entity.setNic("978876543V");
        // entity.setStudentName(studentName);
        // Integer id = studentRepository.saveStudent(entity);
        // System.out.println("Id : " + id);

        CustomerEntity studentEntity = customerRepository.getCustomer(1);
        System.out.println(studentEntity.toString());

        studentEntity.setNic("974476543V");
        customerRepository.updateStudent(studentEntity);

        CustomerEntity updatedStudent = customerRepository.getCustomer(1);
        System.out.println(updatedStudent.toString());

         
        customerRepository.deleteStudent(updatedStudent);

    }
}
