package entity.repository;

import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.CustomerEntity;
import util.SessionFactoryConfiguration;

public class CustomerRepository {

    private static final Object CustomerEntity = null;
    private static final Object customerEntity = null;
    private Session session = SessionFactoryConfiguration.getInstance().getSession();

    public Integer saveStudent(CustomerEntity customerEntity){
        Transaction transaction = session.beginTransaction();
        try {
            Integer id = (Integer)session.save(CustomerEntity);
            transaction.commit();
            return id;
        } catch (Exception e) {
            transaction.rollback();
            return -1;
        }
    }

    public CustomerEntity getStudent(Integer id){
        CustomerEntity studentEntity = session.get(CustomerEntity.class, id);
        return studentEntity;
    }
    
    public void updateStudent(CustomerEntity customerEntity) throws RuntimeException{
        Transaction transaction = session.beginTransaction();
        try {
            session.update(customerEntity);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            throw new RuntimeException("Error at update " + customerEntity.getId());
        }
    }

    public void deleteStudent(CustomerEntity studentEntity) throws RuntimeException{
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(customerEntity);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            throw new RuntimeException("Error at delete " + ((entity.CustomerEntity) customerEntity).getId());
        }
    }

    public entity.CustomerEntity getCustomer(int i) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getCustomer'");
    }
}
