package entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import entity.embeded.CustomerName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "customer")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CustomerEntity {
     // ID attribute
     @Id
     @Column(name = "id")
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Integer id;
 
     // Attribute
     @Column(name = "nic", nullable = false, length = 12)
     private String nic;
 
     //Multivalued Attribute
     @ElementCollection
     @CollectionTable(
         name = "customer_room",
         joinColumns = @JoinColumn(name = "customer_id")
     )
     private List<String> mobiles;

     private CustomerName customerName;
 
     @CreationTimestamp
     @Column(name = "create_date", nullable = false)
     private Date createDate;
}
